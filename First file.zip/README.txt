# Model
For our model, we created three interfaces, which are IShape, IAction and IStatus.

## IShape, AbstractIShape, Shape, ShapeType, Shapes
IShape mainly focuses on representing shapes. It is implemented by AbstractIShape, which is an abstract superclass that hold all the common code and attributes for Shape. We have Shape class that extends the AbstractIShape. We designed the AbstractIShape since we originally thought we are going to have Rectangle and Oval classes. But then we realize that we can combine Rectangle and Oval into Shape class. For Assignment 6, we don't have enough time to combine AbstractIShape and Shape into one class, but we will redesign this part to combine this two in the next assignment. We then have ShapeType enum class that has RECTANGLE and OVAL. Shapes is a class we created to hold our shapes in a list. The relationship between Shapes and Shape is Shapes "has-a" Shape. For next assignment, we will consider to add an IShapes interface for user convenience.

## IAction, Action, ActionType
Interface IAction is mainly used to represent the action with time tick, including start tick and end tick, and status of the animation, including start status and end status. Action implements all the methods from IAction. ActionType is an enum class that stores all the action type we defined, which includes ChangePosition, ChangeColor and ChangeScale.

## IStatus, Position, Color, Scale
IStatus is the interface used to get current status of the animation since we think user might want to check status of all shapes at some point. Position is used to get current position status of the shape, Color is used to get current color status of the shape, and Scale is used to get current scale status of the shape. 

## Relationships between the above three parts
Since AbstracIShape and Shape will have Position, Color and Scale, so there are "has-a" relationships between AbstractIShape and Position, Color, Scale, and there are also "has-a" relationships between Shape and Position, Color, Scale. Since Action will get start status and end status, so Action "extends" iStatus.

## One thing to mention about our design
We only have Shapes that hold a list of shape, instead of having two classes for both shape list and action list, because we want to have action list initialized in each shape so that action is grouped by each shape. In this way, when we want to access action of a shape, we don't need to go over the whole action lists, instead we only need to go to the shape and find one of its actions.
