/**
 * This interface represents a status at a certain tick. It is a super-type for all status.
 */
public interface IStatus {

  /**
   * Get the current status of Color, Position, or Scale in a formatted string value.
   * @return a String value represents the current shape status.
   */
  String getCurrentStatus();

}
