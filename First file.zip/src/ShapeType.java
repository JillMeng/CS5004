/**
 * This class defines an enum ShapeType, representing the type of a shape.
 */
public enum ShapeType {
  RECTANGLE,
  OVAL
}
