package Model;

public interface IStatus {



}
