package Model;

public enum ActionType {
  ChangeColor,
  ChangePosition,
  ChangeScale
}
