package Model;

public enum ShapeType {
  RECTANGLE,
  OVAL
}
